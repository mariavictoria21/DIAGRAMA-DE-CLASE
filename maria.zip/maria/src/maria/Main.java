/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package maria;

/**
 *
 * @author USUARIO
 */
// Clase Catedratico
import java.util.Scanner; // Importar la clase Scanner para la entrada del usuario

// Clase Catedratico
class Catedratico {
    private static int contador = 0; // Variable estatica para contar el numero de catedraticos creados
    private int codigocatedratico; // Atributo para almacenar el codigo del catedratico
    private String nombre; // Atributo para almacenar el nombre del catedratico
    private String direccion; // Atributo para almacenar la direccion del catedratico
    private String telefono; // Atributo para almacenar el telefono del catedratico
    private String profesion; // Atributo para almacenar la profesion del catedratico

    // Constructor de la clase Catedratico
    public Catedratico(String nombre, String direccion, String telefono, String profesion) {
        this.codigocatedratico = ++contador; // Incrementar y asignar el codigo de catedratico
        this.nombre = nombre; // Asignar el nombre
        this.direccion = direccion; // Asignar la direccion
        this.telefono = telefono; // Asignar el telefono
        this.profesion = profesion; // Asignar la profesion
    }

    // Metodo para obtener el nombre del catedratico
    public String getNombre() {
        return nombre;
    }

    // Metodo para imprimir los datos del catedratico
    public void imprimirDatos() {
        System.out.println("Codigo Catedratico: " + codigocatedratico);
        System.out.println("Nombre: " + nombre);
        System.out.println("Direccion: " + direccion);
        System.out.println("Telefono: " + telefono);
        System.out.println("Profesion: " + profesion);
    }
}

// Clase Alumno
class Alumno {
    private static int contador = 0; // Variable estatica para contar el numero de alumnos creados
    private int carnet; // Atributo para almacenar el carnet del alumno
    private String nombre; // Atributo para almacenar el nombre del alumno
    private String direccion; // Atributo para almacenar la direccion del alumno
    private String telefono; // Atributo para almacenar el telefono del alumno
    private int edad; // Atributo para almacenar la edad del alumno

    // Constructor de la clase Alumno
    public Alumno(String nombre, String direccion, String telefono, int edad) {
        this.carnet = ++contador; // Incrementar y asignar el carnet del alumno
        this.nombre = nombre; // Asignar el nombre
        this.direccion = direccion; // Asignar la direccion
        this.telefono = telefono; // Asignar el telefono
        this.edad = edad; // Asignar la edad
    }

    // Metodo para obtener el nombre del alumno
    public String getNombre() {
        return nombre;
    }

    // Metodo para imprimir los datos del alumno
    public void imprimirDatos() {
        System.out.println("Carnet: " + carnet);
        System.out.println("Nombre: " + nombre);
        System.out.println("Direccion: " + direccion);
        System.out.println("Telefono: " + telefono);
        System.out.println("Edad: " + edad);
    }
}

// Clase Curso
class Curso {
    private int id; // Atributo para almacenar el ID del curso
    private String titulo; // Atributo para almacenar el titulo del curso
    private int nummaxalumnos; // Atributo para almacenar el numero maximo de alumnos
    private int creditos; // Atributo para almacenar los creditos del curso
    private Catedratico catedratico; // Atributo para almacenar el catedratico asignado al curso
    private int alumnosasignados; // Atributo para contar el numero de alumnos asignados

    // Constructor de la clase Curso
    public Curso(int id, String titulo, int nummaxalumnos, int creditos, Catedratico catedratico) {
        this.id = id; // Asignar el ID
        this.titulo = titulo; // Asignar el titulo
        this.nummaxalumnos = nummaxalumnos; // Asignar el numero maximo de alumnos
        this.creditos = creditos; // Asignar los creditos
        this.catedratico = catedratico; // Asignar el catedratico
        this.alumnosasignados = 0; // Inicializar los alumnos asignados en 0
    }

    // Metodo para obtener el titulo del curso
    public String getTitulo() {
        return titulo;
    }

    // Metodo para verificar si hay espacio en el curso
    public boolean verificaEspacio() {
        return alumnosasignados < nummaxalumnos;
    }

    // Metodo para incrementar el numero de alumnos asignados
    public void incrementarAlumnosAsignados() {
        alumnosasignados++;
    }

    // Metodo para imprimir los datos del curso
    public void imprimirDatosCurso() {
        System.out.println("ID Curso: " + id);
        System.out.println("Titulo: " + titulo);
        System.out.println("Creditos: " + creditos);
        System.out.println("Catedratico: " + catedratico.getNombre());
        System.out.println("Numero de Alumnos Asignados: " + alumnosasignados);
        System.out.println("Maximo de Alumnos: " + nummaxalumnos);
    }
}

// Clase Asignacion
class Asignacion {
    private Alumno alumno; // Atributo para almacenar el alumno al que se asignara un curso

    // Constructor de la clase Asignacion
    public Asignacion(Alumno alumno) {
        this.alumno = alumno; // Asignar el alumno
    }

    // Metodo para agregar un curso a la asignacion del alumno
    public void addCurso(Curso curso) {
        if (curso.verificaEspacio()) { // Verificar si hay espacio en el curso
            curso.incrementarAlumnosAsignados(); // Incrementar el numero de alumnos asignados
            System.out.println("Curso " + curso.getTitulo() + " asignado a " + alumno.getNombre());
        } else {
            System.out.println("No hay espacio en el curso " + curso.getTitulo());
        }
    }
}

// Clase Main
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Crear un objeto Scanner para leer la entrada del usuario

        // Ingresar datos de los catedraticos
        System.out.println("Ingrese datos del Catedratico 1:");
        Catedratico catedratico1 = crearCatedratico(scanner);

        System.out.println("Ingrese datos del Catedratico 2:");
        Catedratico catedratico2 = crearCatedratico(scanner);

        System.out.println("Ingrese datos del Catedratico 3:");
        Catedratico catedratico3 = crearCatedratico(scanner);

        // Ingresar datos de los cursos
        System.out.println("Ingrese datos del Curso 1:");
        Curso curso1 = crearCurso(scanner, catedratico1);

        System.out.println("Ingrese datos del Curso 2:");
        Curso curso2 = crearCurso(scanner, catedratico2);

        System.out.println("Ingrese datos del Curso 3:");
        Curso curso3 = crearCurso(scanner, catedratico3);

        // Ingresar datos de los alumnos
        System.out.println("Ingrese datos del Alumno 1:");
        Alumno alumno1 = crearAlumno(scanner);

        System.out.println("Ingrese datos del Alumno 2:");
        Alumno alumno2 = crearAlumno(scanner);

        System.out.println("Ingrese datos del Alumno 3:");
        Alumno alumno3 = crearAlumno(scanner);

        // Asignar cursos a los alumnos
        System.out.println("Asignando cursos a los alumnos:");
        Asignacion asignacion1 = new Asignacion(alumno1);
        asignacion1.addCurso(curso1);
        asignacion1.addCurso(curso2);

        Asignacion asignacion2 = new Asignacion(alumno2);
        asignacion2.addCurso(curso1);
        asignacion2.addCurso(curso3);

        Asignacion asignacion3 = new Asignacion(alumno3);
        asignacion3.addCurso(curso3);

        // Imprimir detalles de catedraticos
        System.out.println("\nDatos de los Catedraticos:");
        catedratico1.imprimirDatos();
        catedratico2.imprimirDatos();
        catedratico3.imprimirDatos();

        // Imprimir detalles de alumnos
        System.out.println("\nDatos de los Alumnos:");
        alumno1.imprimirDatos();
        alumno2.imprimirDatos();
        alumno3.imprimirDatos();

        // Imprimir detalles de cursos
        System.out.println("\nDatos de los Cursos:");
        curso1.imprimirDatosCurso();
        curso2.imprimirDatosCurso();
        curso3.imprimirDatosCurso();

        scanner.close(); // Cerrar el objeto Scanner
    }

    // Metodo para crear un Catedratico solicitando datos al usuario
    private static Catedratico crearCatedratico(Scanner scanner) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine(); // Leer el nombre del catedratico
        System.out.print("Direccion: ");
        String direccion = scanner.nextLine(); // Leer la direccion del catedratico
        System.out.print("Telefono: ");
        String telefono = scanner.nextLine(); // Leer el telefono del catedratico
        System.out.print("Profesion: ");
        String profesion = scanner.nextLine(); // Leer la profesion del catedratico

        return new Catedratico(nombre, direccion, telefono, profesion); // Retornar una nueva instancia de Catedratico
    }

    // Metodo para crear un Alumno solicitando datos al usuario
    private static Alumno crearAlumno(Scanner scanner) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine(); // Leer el nombre del alumno
        System.out.print("Direccion: ");
        String direccion = scanner.nextLine(); // Leer la direccion del alumno
        System.out.print("Telefono: ");
        String telefono = scanner.nextLine(); // Leer el telefono del alumno
        System.out.print("Edad: ");
        int edad = scanner.nextInt(); // Leer la edad del alumno
        scanner.nextLine(); // Limpiar el buffer de entrada

        return new Alumno(nombre, direccion, telefono, edad); // Retornar una nueva instancia de Alumno
    }

    // Metodo para crear un Curso solicitando datos al usuario
    private static Curso crearCurso(Scanner scanner, Catedratico catedratico) {
        System.out.print("ID del Curso: ");
        int id = scanner.nextInt(); // Leer el ID del curso
        System.out.print("Titulo: ");
        scanner.nextLine(); // Limpiar el buffer de entrada
        String titulo = scanner.nextLine(); // Leer el titulo del curso
        System.out.print("Numero maximo de alumnos: ");
        int nummaxalumnos = scanner.nextInt(); // Leer el numero maximo de alumnos
        System.out.print("Creditos: ");
        int creditos = scanner.nextInt(); // Leer los creditos del curso
        scanner.nextLine(); // Limpiar el buffer de entrada

        return new Curso(id, titulo, nummaxalumnos, creditos, catedratico); // Retornar una nueva instancia de Curso
    }
}
